# coding=utf-8

from ..del_file import *